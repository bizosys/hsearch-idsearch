package com.bizosys.hsearch.unstructured.util;

public class ContentField {
	public int name;
	public String content;
	public boolean searchable;
	public int weight;
	public boolean keepOriginal;
}
