package com.bizosys.hsearch.unstructured.util;

import java.util.List;

public class IndexableFile {
	
	public class Section {
		String name;
		String text;
	}
	
	public List<Section> sections;
	
}
