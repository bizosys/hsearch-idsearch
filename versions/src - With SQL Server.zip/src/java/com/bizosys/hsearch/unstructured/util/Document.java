package com.bizosys.hsearch.unstructured.util;

import java.util.List;

import com.bizosys.hsearch.idsearch.meta.DocMetaTableRow;

public class Document {
	
	public DocMetaTableRow meta;
	public List<ContentField> fields = null;

}
