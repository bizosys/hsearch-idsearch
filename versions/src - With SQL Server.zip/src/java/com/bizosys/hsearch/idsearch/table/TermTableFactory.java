package com.bizosys.hsearch.idsearch.table;

public class TermTableFactory 
{
	public static ITermTable getTable() 
	{
		return new TermTable();
		
	}
}
